You can check the docs over [here](https://dapd007.github.io/v-calendar-scheduler/)
