# Overview

The calendar comes with **three** different views:

- Month
- Week
- Day

All three of them are enabled by default and can be disabled globally or per instance.

You can play around with the views in the demo below:

<vue-scheduler/>