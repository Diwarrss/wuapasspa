---
home: true
actionText: Get Started →
actionLink: /guide/
footer: MIT Licensed | Copyright © 2018-present David Paternina
---

<style>
    .home {
        max-width: 1200px;
    }
</style>

<vue-scheduler/>

Created by [David Paternina](http://davidpaternina.com/)